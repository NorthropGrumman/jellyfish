package ${groupId}.${artifactId};

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;

@Component
public class MyComponent {

   private IPersonService personService;

   public String getMessage() {
      return "Hello, " + personService.getFirstName();
   }

   @Activate
   public void activate() {
   }

   @Deactivate
   public void deactivate() {
   }

   @Reference(cardinality = ReferenceCardinality.MANDATORY, policy = ReferencePolicy.STATIC)
   public void setPersonService(IPersonService ref) {
      this.personService = ref;
   }

   public void removePersonService(IPersonService ref) {
      setPersonService(null);
   }
}
