# ${projectName}

## Summary
This repository consist of the ${projectName}.

## More about extending and using of the JellyFish product line can be found on the CEACIDE wiki.
http://10.207.42.43/confluence/display/SEAS/JellyFish+Implementation
