package ${groupId}.${artifactId};

public interface IPersonService {

   String getFirstName();
}
