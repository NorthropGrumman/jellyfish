package $groupId.$artifactId;

public class Sample
{

   public static void main(String[] args)
   {
      Sample sample = new Sample();
      System.out.println(sample.getHelloWorld());
   }

   public String getHelloWorld()
   {
      return "Hello World";
   }

}
